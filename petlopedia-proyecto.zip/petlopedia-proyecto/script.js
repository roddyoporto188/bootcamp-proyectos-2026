function toggleLogin(elemento) {
    elemento.innerText = (elemento.innerText === "Iniciar sesión") ? "Cerrar sesión" : "Iniciar sesión";
}

function quitarBoton(elemento) {
    elemento.remove();
}

function darLike(titulo, boton) {
    alert("¡Te gustó la definición de: " + titulo + "!");
    let contenedor = boton.parentElement;
    let contador = contenedor.querySelector(".contador");
    contador.innerText = parseInt(contador.innerText) + 1;
}